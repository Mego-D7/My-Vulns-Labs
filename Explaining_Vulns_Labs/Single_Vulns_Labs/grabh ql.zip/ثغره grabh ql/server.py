from flask import Flask, request, jsonify, send_from_directory
import graphene

app = Flask(__name__)


users_db = [
    {"id": 1, "username": "admin", "password": "admin123", "secret": "FLAG{ADMIN_SECRET}"},
    {"id": 2, "username": "menna", "password": "1234", "secret": "FLAG{USER_SECRET}"},
]


class User(graphene.ObjectType):
    id = graphene.Int()
    username = graphene.String()
    password = graphene.String()
    secret = graphene.String()


class LoginResult(graphene.ObjectType):
    message = graphene.String()
    token = graphene.String()


class Query(graphene.ObjectType):

    users = graphene.List(User)

    def resolve_users(root, info):
        return users_db


class Login(graphene.Mutation):

    class Arguments:
        username = graphene.String()
        password = graphene.String()

    Output = LoginResult

    def mutate(root, info, username, password):

        for u in users_db:
            if u["username"] == username and u["password"] == password:
                return LoginResult(
                    message="success",
                    token="fake-token"
                )

        return LoginResult(
            message="failed",
            token=""
        )


class Mutation(graphene.ObjectType):
    login = Login.Field()


schema = graphene.Schema(
    query=Query,
    mutation=Mutation
)


@app.route("/")
def home():
    return send_from_directory(".", "index.html")


@app.route("/admin")
def admin():
    return send_from_directory(".", "admin.html")


@app.route("/graphql", methods=["POST"])
def graphql():

    data = request.get_json()

    result = schema.execute(
        data.get("query")
    )

    return jsonify(result.data)


if __name__ == "__main__":
    app.run(debug=True)