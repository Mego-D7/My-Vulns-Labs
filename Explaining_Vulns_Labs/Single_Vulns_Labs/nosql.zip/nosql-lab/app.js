const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
app.set('query parser', 'extended');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/cybershopdb');

const User = mongoose.model('User', {
  username: String, password: String, role: String, secret: String
});

const Product = mongoose.model('Product', {
  name: String, price: Number, category: String,
  description: String, image: String, visible: Boolean, badge: String
});

async function seed() {
  const userCount = await User.countDocuments();
  if (userCount === 0) {
    await User.create([
      { username: 'admin', password: 'CyberAdmin@2024!', role: 'admin', secret: '🚩 FLAG{NoSQL_Auth_Bypass_SUCCESS} - Welcome Admin!' },
      { username: 'administrator', password: 'SuperSecret!99', role: 'admin', secret: '🚩 FLAG{REGEX_BYPASS_SUCCESS} - Found via $regex!' },
      { username: 'user1', password: 'pass123', role: 'user', secret: 'Nothing special...' }
    ]);
    console.log(' Users created');
  }
  const productCount = await Product.countDocuments();
  if (productCount === 0) {
    await Product.create([
      { name: 'Kali Linux USB', price: 29, category: 'tools', description: 'Bootable Kali Linux 2024 on 64GB USB', image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=400&h=300&fit=crop', visible: true, badge: 'POPULAR' },
      { name: 'Network Analyzer Pro', price: 149, category: 'tools', description: 'Professional packet capture tool', image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400&h=300&fit=crop', visible: true, badge: 'NEW' },
      { name: 'Bug Bounty Masterclass', price: 99, category: 'courses', description: 'Complete bug bounty hunting guide', image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=400&h=300&fit=crop', visible: true, badge: '' },
      { name: 'Ethical Hacking Bootcamp', price: 199, category: 'courses', description: 'Zero to certified ethical hacker', image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=400&h=300&fit=crop', visible: true, badge: 'HOT' },
      { name: 'YubiKey Security Token', price: 59, category: 'hardware', description: 'Hardware 2FA for maximum security', image: 'https://images.unsplash.com/photo-1614064641938-3bbee52942c7?w=400&h=300&fit=crop', visible: true, badge: '' },
      { name: ' Zero-Day Exploit Pack', price: 9999, category: 'secret', description: 'CLASSIFIED: Advanced exploitation toolkit', image: 'https://images.unsplash.com/photo-1563206767-5b18f218e8de?w=400&h=300&fit=crop', visible: false, badge: 'SECRET' },
      { name: ' Dark Web Monitor', price: 4999, category: 'secret', description: 'CLASSIFIED: Real-time dark web intel', image: 'https://images.unsplash.com/photo-1510511459019-5dda7724fd87?w=400&h=300&fit=crop', visible: false, badge: 'SECRET' },
      { name: ' NSA-Grade Encryption Suite', price: 7499, category: 'secret', description: 'CLASSIFIED: Military-grade encryption', image: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=400&h=300&fit=crop', visible: false, badge: 'SECRET' }
    ]);
    console.log(' Products created');
  }
}
seed();

const CSS = `
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Rajdhani:wght@400;600;700&family=Orbitron:wght@700;900&display=swap" rel="stylesheet">
<style>
:root{--bg:#050a0f;--bg2:#0a1520;--bg3:#0f1f30;--accent:#00ff88;--accent2:#00ccff;--danger:#ff3366;--warn:#ffaa00;--text:#c8d8e8;--text2:#7a9bb5;--border:#1a3a5c;}
*{margin:0;padding:0;box-sizing:border-box;}
body{background:var(--bg);color:var(--text);font-family:'Rajdhani',sans-serif;min-height:100vh;}
body::before{content:'';position:fixed;inset:0;background-image:linear-gradient(rgba(0,255,136,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(0,255,136,0.03) 1px,transparent 1px);background-size:50px 50px;pointer-events:none;z-index:0;}
nav{position:sticky;top:0;z-index:100;background:rgba(5,10,15,0.95);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);padding:0 2rem;display:flex;align-items:center;justify-content:space-between;height:64px;}
.logo{font-family:'Orbitron',monospace;font-size:1.3rem;font-weight:900;color:var(--accent);text-decoration:none;letter-spacing:2px;}
.logo span{color:var(--accent2);}
.nav-links{display:flex;gap:0.5rem;}
.nav-links a{color:var(--text2);text-decoration:none;padding:0.5rem 1rem;border-radius:4px;font-weight:600;font-size:0.9rem;letter-spacing:1px;text-transform:uppercase;transition:all 0.2s;border:1px solid transparent;}
.nav-links a:hover,.nav-links a.active{color:var(--accent);border-color:var(--accent);background:rgba(0,255,136,0.05);}
.container{max-width:1200px;margin:0 auto;padding:2rem;position:relative;z-index:1;}
.hero{padding:5rem 2rem 4rem;text-align:center;position:relative;z-index:1;}
.hero-badge{display:inline-block;background:rgba(0,255,136,0.1);border:1px solid var(--accent);color:var(--accent);font-family:'Share Tech Mono',monospace;font-size:0.75rem;padding:0.3rem 1rem;border-radius:2px;letter-spacing:3px;margin-bottom:1.5rem;animation:pulse 2s infinite;}
@keyframes pulse{0%,100%{opacity:1;}50%{opacity:0.6;}}
.hero h1{font-family:'Orbitron',monospace;font-size:clamp(2rem,5vw,4rem);font-weight:900;line-height:1.1;margin-bottom:1rem;background:linear-gradient(135deg,var(--accent),var(--accent2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.hero p{color:var(--text2);font-size:1.1rem;max-width:500px;margin:0 auto 2rem;}
.btn{background:transparent;border:1px solid var(--accent);color:var(--accent);padding:0.6rem 1.5rem;border-radius:4px;font-family:'Rajdhani',sans-serif;font-weight:700;font-size:0.9rem;letter-spacing:2px;text-transform:uppercase;cursor:pointer;transition:all 0.2s;text-decoration:none;display:inline-block;}
.btn:hover{background:rgba(0,255,136,0.1);box-shadow:0 0 20px rgba(0,255,136,0.3);}
.btn-blue{border-color:var(--accent2);color:var(--accent2);}
.btn-blue:hover{background:rgba(0,204,255,0.1);}
.stats-bar{display:flex;gap:2rem;padding:1rem 2rem;background:var(--bg2);border-top:1px solid var(--border);border-bottom:1px solid var(--border);margin-bottom:2rem;font-family:'Share Tech Mono',monospace;font-size:0.8rem;color:var(--text2);flex-wrap:wrap;position:relative;z-index:1;}
.stats-bar .stat span{color:var(--accent);font-weight:bold;}
.filter-bar{display:flex;gap:1rem;align-items:center;padding:1.5rem 2rem;background:var(--bg2);border:1px solid var(--border);border-radius:8px;margin-bottom:2rem;flex-wrap:wrap;}
.filter-bar label{font-family:'Share Tech Mono',monospace;color:var(--accent);font-size:0.8rem;letter-spacing:2px;}
.filter-bar input{flex:1;min-width:200px;background:var(--bg3);border:1px solid var(--border);color:var(--text);padding:0.6rem 1rem;border-radius:4px;font-family:'Share Tech Mono',monospace;font-size:0.9rem;outline:none;transition:border-color 0.2s;}
.filter-bar input:focus{border-color:var(--accent);box-shadow:0 0 20px rgba(0,255,136,0.3);}
.terminal-line{font-family:'Share Tech Mono',monospace;color:var(--text2);font-size:0.8rem;padding:0.8rem 1rem;background:var(--bg3);border-left:2px solid var(--accent);border-radius:0 4px 4px 0;margin-bottom:2rem;}
.terminal-line .q{color:var(--danger);}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1.5rem;margin-bottom:4rem;}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:8px;overflow:hidden;transition:all 0.3s;position:relative;}
.card:hover{border-color:var(--accent);transform:translateY(-4px);box-shadow:0 8px 30px rgba(0,255,136,0.15);}
.card.secret{border-color:var(--danger);}
.card.secret:hover{box-shadow:0 8px 30px rgba(255,51,102,0.2);}
.card img{width:100%;height:200px;object-fit:cover;filter:saturate(0.7) brightness(0.8);transition:filter 0.3s;}
.card:hover img{filter:saturate(1) brightness(0.9);}
.badge{position:absolute;top:12px;right:12px;padding:0.2rem 0.6rem;border-radius:2px;font-family:'Share Tech Mono',monospace;font-size:0.65rem;letter-spacing:2px;}
.badge-popular{background:rgba(0,255,136,0.2);border:1px solid var(--accent);color:var(--accent);}
.badge-new{background:rgba(0,204,255,0.2);border:1px solid var(--accent2);color:var(--accent2);}
.badge-hot{background:rgba(255,150,0,0.2);border:1px solid #ff9600;color:#ff9600;}
.badge-secret{background:rgba(255,51,102,0.2);border:1px solid var(--danger);color:var(--danger);animation:pulse 1.5s infinite;}
.card-body{padding:1.2rem;}
.card-name{font-family:'Orbitron',monospace;font-size:0.9rem;font-weight:700;color:var(--text);margin-bottom:0.5rem;}
.card-desc{color:var(--text2);font-size:0.85rem;margin-bottom:1rem;line-height:1.4;}
.card-footer{display:flex;justify-content:space-between;align-items:center;}
.price{font-family:'Share Tech Mono',monospace;font-size:1.2rem;color:var(--accent);font-weight:bold;}
.card.secret .price{color:var(--danger);}
.error-box{background:var(--bg2);border:1px solid var(--danger);border-radius:8px;padding:1.5rem;margin-bottom:2rem;font-family:'Share Tech Mono',monospace;font-size:0.85rem;}
.error-title{color:var(--danger);font-size:1rem;margin-bottom:1rem;}
.error-detail div{color:var(--text2);line-height:2;}
.error-detail span{color:var(--accent2);}
.login-wrap{min-height:calc(100vh - 64px);display:flex;align-items:center;justify-content:center;padding:2rem;position:relative;z-index:1;}
.login-box{width:100%;max-width:460px;background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:2.5rem;}
.login-icon{text-align:center;font-size:3rem;margin-bottom:1rem;}
.login-title{font-family:'Orbitron',monospace;font-size:1.3rem;text-align:center;color:var(--accent);margin-bottom:0.5rem;letter-spacing:2px;}
.login-sub{text-align:center;color:var(--text2);font-size:0.85rem;margin-bottom:2rem;font-family:'Share Tech Mono',monospace;}
.form-group{margin-bottom:1.2rem;}
.form-group label{display:block;color:var(--accent);font-family:'Share Tech Mono',monospace;font-size:0.75rem;letter-spacing:2px;margin-bottom:0.5rem;}
.form-group input{width:100%;background:var(--bg3);border:1px solid var(--border);color:var(--text);padding:0.8rem 1rem;border-radius:4px;font-family:'Share Tech Mono',monospace;font-size:0.95rem;outline:none;transition:border-color 0.2s;}
.form-group input:focus{border-color:var(--accent);}
.btn-full{width:100%;text-align:center;padding:0.9rem;font-size:1rem;margin-top:0.5rem;}
.alert{padding:1rem 1.5rem;border-radius:6px;margin-bottom:1.5rem;font-family:'Share Tech Mono',monospace;font-size:0.85rem;}
.alert-error{background:rgba(255,51,102,0.1);border:1px solid var(--danger);color:var(--danger);}
.hint-box{background:rgba(255,170,0,0.05);border:1px solid var(--warn);border-radius:8px;padding:1rem 1.5rem;margin-bottom:1.5rem;font-family:'Share Tech Mono',monospace;font-size:0.78rem;color:var(--warn);line-height:1.8;}
.hint-box .hint-title{font-size:0.85rem;margin-bottom:0.5rem;letter-spacing:2px;}
.hint-box code{color:var(--accent2);background:var(--bg3);padding:0.1rem 0.4rem;border-radius:3px;}
.success-wrap{min-height:calc(100vh - 64px);display:flex;align-items:center;justify-content:center;padding:2rem;position:relative;z-index:1;}
.success-box{max-width:600px;width:100%;background:var(--bg2);border:1px solid var(--accent);border-radius:12px;padding:3rem;text-align:center;box-shadow:0 0 20px rgba(0,255,136,0.3);}
.flag-box{background:var(--bg3);border:1px solid var(--accent);border-radius:6px;padding:1rem 1.5rem;font-family:'Share Tech Mono',monospace;color:var(--accent);font-size:1rem;margin:1.5rem 0;word-break:break-all;}
.no-results{text-align:center;padding:4rem 2rem;color:var(--text2);font-family:'Share Tech Mono',monospace;}
</style>`;

function nav(active='') {
  return `<nav>
    <a href="/" class="logo">CYBER<span>SHOP</span></a>
    <div class="nav-links">
      <a href="/filter?category=tools" class="${active==='tools'?'active':''}">Tools</a>
      <a href="/filter?category=courses" class="${active==='courses'?'active':''}">Courses</a>
      <a href="/filter?category=hardware" class="${active==='hardware'?'active':''}">Hardware</a>
      <a href="/login" class="${active==='login'?'active':''}">Admin Login</a>
    </div>
  </nav>`;
}

function page(title, body, active='') {
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} | CyberShop</title>${CSS}</head><body>${nav(active)}${body}</body></html>`;
}

// HOME
app.get('/', (req, res) => {
  res.send(page('Home', `
    <div class="hero">
      <div class="hero-badge">// SECURE MARKETPLACE //</div>
      <h1>Elite Cyber<br>Security Store</h1>
      <p>Professional tools, courses, and hardware for ethical hackers.</p>
      <a href="/filter?category=tools" class="btn">Browse Tools</a>&nbsp;&nbsp;
      <a href="/filter?category=courses" class="btn btn-blue">View Courses</a>
    </div>
    <div class="stats-bar">
      <div class="stat">STATUS: <span>ONLINE</span></div>
      <div class="stat">PRODUCTS: <span>5 PUBLIC</span></div>
      <div class="stat">ENCRYPTION: <span>AES-256</span></div>
    </div>`));
});

// LAB 1: $where NoSQL Injection
app.get('/filter', async (req, res) => {
  const { category } = req.query;
  try {
    const products = await Product.find({ $where: `this.category == '${category}'` });

    const cards = products.length === 0
      ? `<div class="no-results"><div></div><p>No products found</p></div>`
      : products.map(p => {
          const isSecret = p.badge === 'SECRET';
          const badgeHtml = p.badge ? `<div class="badge badge-${p.badge.toLowerCase()}">${p.badge}</div>` : '';
          return `<div class="card ${isSecret ? 'secret' : ''}">
            <img src="${p.image}" alt="${p.name}" onerror="this.src='https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=400&h=300&fit=crop'">
            ${badgeHtml}
            <div class="card-body">
              <div class="card-name">${p.name}</div>
              <div class="card-desc">${p.description}</div>
              <div class="card-footer">
                <div class="price">$${p.price}</div>
                <a href="#" class="btn" style="padding:0.4rem 0.8rem;font-size:0.75rem">BUY</a>
              </div>
            </div>
          </div>`;
        }).join('');

    res.send(page('Products', `
      <div class="container">
        <div class="terminal-line">$ db.products.find({ $where: "this.category == '<span class="q">${category}</span>'" }) → ${products.length} docs</div>
        <div class="filter-bar">
          <label>FILTER:</label>
          <form method="GET" action="/filter" style="display:flex;gap:1rem;flex:1;flex-wrap:wrap">
            <input name="category" placeholder="Enter category..." value="${category || ''}">
            <button type="submit" class="btn">SEARCH</button>
          </form>
        </div>
        <div class="grid">${cards}</div>
      </div>`, category));

  } catch (e) {
    res.send(page('Error', `
      <div class="container">
        <div class="error-box">
          <div class="error-title">⚠ DATABASE ERROR — UNHANDLED EXCEPTION</div>
          <div class="error-detail">
            <div>Error: <span>${e.message}</span></div>
            <div>Database: <span>MongoDB (Mongoose v${mongoose.version})</span></div>
            <div>Node.js: <span>${process.version}</span></div>
            <div>Query: <span>$where: "this.category == '${category}'"</span></div>
            <div>Host: <span>localhost:27017/cybershopdb</span></div>
          </div>
        </div>
        <a href="/" class="btn">← BACK</a>
      </div>`));
  }
});

// LAB 2
app.get('/login', (req, res) => {
  const err = req.query.error ? `<div class="alert alert-error">⚠ ACCESS DENIED — Invalid credentials</div>` : '';
  res.send(page('Login', `
    <div class="login-wrap">
      <div class="login-box">
        <div class="login-icon"></div>
        <div class="login-title">ADMIN ACCESS</div>
        <div class="login-sub">// AUTHORIZED PERSONNEL ONLY //</div>
        ${err}

        <form method="POST" action="/login">
          <div class="form-group"><label>USERNAME</label><input name="username" placeholder="Enter username" autocomplete="off"></div>
          <div class="form-group"><label>PASSWORD</label><input name="password" type="password" placeholder="Enter password"></div>
          <button type="submit" class="btn btn-full">AUTHENTICATE</button>
        </form>
      </div>
    </div>`, 'login'));
});

app.post('/login', async (req, res) => {
  let username = req.body.username;
  let password = req.body.password;

  try {
    const user = await User.findOne({ username: username, password: password });

    if (user) {
      res.send(page('Access Granted', `
        <div class="success-wrap">
          <div class="success-box">
            <div style="font-size:3rem;margin-bottom:1rem"></div>
            <div class="login-title" style="margin-bottom:0.5rem">ACCESS GRANTED</div>
            <p style="color:var(--text2);font-family:'Share Tech Mono',monospace;font-size:0.85rem;margin-bottom:1.5rem">
              Welcome, <strong style="color:var(--accent)">${user.username}</strong> [${user.role.toUpperCase()}]
            </p>
            <div class="flag-box">${user.secret}</div>
            <a href="/" class="btn">← BACK TO STORE</a>
          </div>
        </div>`));
    } else {
      res.redirect('/login?error=1');
    }
  } catch (e) {
    res.send(`<h2 style="color:red;font-family:monospace;padding:2rem">Error: ${e.message}</h2>`);
  }
});

app.listen(3000, () => console.log(' CyberShop running on http://localhost:3000'));
