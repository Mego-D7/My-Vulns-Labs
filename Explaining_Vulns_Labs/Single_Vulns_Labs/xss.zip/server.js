const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

// إعدادات السيرفر لقراءة البيانات من الفورم
app.use(express.urlencoded({ extended: true }));

// مصفوفة لتخزين الكومنتات (Stored XSS Lab)
let comments = [];

// دالة تسجيل العمليات في ملف reports.txt
function saveLog(message) {
    const timestamp = new Date().toLocaleString();
    const logEntry = `[LOG] ${timestamp} - ${message}\n`;
    fs.appendFileSync('reports.txt', logEntry);
    console.log(logEntry); // عشان يظهر قدامك في التيرمنال برضه
}

// 1. مسار صفحة الدخول (Reflected + DOM XSS Lab)
app.get('/', (req, res) => {
    res.send(`
        <html>
        <head><title>Security Lab - XSS</title></head>
        <body style="font-family: Arial; text-align: center; background: #f4f4f4;">
            <h2>Graduation Project - Security Lab</h2>
            <div id="dom-area" style="color: blue; font-weight: bold;"></div> <hr>
            <h3>1. Reflected XSS (Login Form)</h3>
            <form method="POST" action="/login">
                <input type="text" name="username" placeholder="Username" required><br><br>
                <input type="password" name="password" placeholder="Password" required><br><br>
                <button type="submit">Login</button>
            </form>
            <hr>
            <h3>2. Stored XSS (Comments Section)</h3>
            <form method="POST" action="/add-comment">
                <textarea name="comment" placeholder="Write a comment..."></textarea><br>
                <button type="submit">Post Comment</button>
            </form>
            <div id="comments-section" style="margin-top:20px; text-align: left; display: inline-block;">
                ${comments.map(c => `<div>${c}</div>`).join('<br>')}
            </div>

            <script>
                // كود الـ DOM-based XSS
                // بياخد أي حاجة بعد كلمة ?name= في الرابط ويعرضها فوراً
                const params = new URLSearchParams(window.location.search);
                const name = params.get('name');
                if (name) {
                    document.getElementById('dom-area').innerHTML = "Welcome, " + name;
                }
            </script>
        </body>
        </html>
    `);
});

// 2. معالجة الـ Reflected XSS
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    saveLog(`[REFLECTED] Login Attempt - User: ${username}, Pass: ${password}`);
    
    // الثغرة هنا: بنرجع اليوزر نيم زي ما هو في الصفحة
    res.send(`
        <h2 style="color: red;">Login Failed!</h2>
        <p>Sorry, the user <b>${username}</b> is not found in our database.</p>
        <a href="/">Go Back</a>
    `);
});

// 3. معالجة الـ Stored XSS
app.post('/add-comment', (req, res) => {
    const { comment } = req.body;
    comments.push(comment); // تخزين الكود الخبيث في السيرفر
    saveLog(`[STORED] New Comment added: ${comment}`);
    res.redirect('/');
});

// تشغيل السيرفر
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
    saveLog("Server Started Successfully.");
});